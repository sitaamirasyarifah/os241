#include <stdio.h>

int main() {
    printf("Hello WEEK03\n");
    return 0;
}

